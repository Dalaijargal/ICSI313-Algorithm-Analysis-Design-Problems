import numpy
import gr 
import networkx as nx  

def calc_fitness(remove_nodes):
    graph = gr.graph
    reduced_graph = gr.remove_nodes(graph, remove_nodes)
    return gr.calculate_fitness(reduced_graph)

def calc_pop_fitness(pop) :
    fitness_min = float('inf') 
    for i in range(len(pop)) :
        fitness = calc_fitness(pop[i])
        if fitness < fitness_min :
            fitness_min = fitness
    return fitness_min

# select exactly 2 best parents 
def select_mating_pool(pop) :
    pop_fitness = {}
    for i in range(len(pop)) :
        pop_fitness[i] = calc_fitness(pop[i])
    sorted_pop_fitness = sorted(pop_fitness.items(), key=lambda x: x[1], reverse=False)
    parent1 = pop[sorted_pop_fitness[0][0]]
    parent2 = pop[sorted_pop_fitness[1][0]]
    return [parent1, parent2] 
    
def crossover(parents) :
    offsprings = parents.copy()
    crossover_point = int(len(parents[0]) / 2)
    offsprings[0] = parents[0][:crossover_point] + parents[1][crossover_point:]
    offsprings[1] = parents[1][:crossover_point] + parents[0][crossover_point:]
    return offsprings

def mutation (offspring) :
    mutation_point = numpy.random.randint(0, len(offspring))
    new_gene = numpy.random.randint(0, len(gr.graph.nodes))
    offspring[mutation_point] = new_gene
    return offspring
