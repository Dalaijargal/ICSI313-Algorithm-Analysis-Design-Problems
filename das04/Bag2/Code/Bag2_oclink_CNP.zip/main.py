import numpy 
import ga 
import helpers 
import gr 

graph = gr.graph

pop_size = 100
gene_cnt = 380
generation_cnt = 600

# print(helpers.select_random_distinct_numbers(3, 0, 4))

# Creating initial population randomly 
population = []
for i in range(pop_size):
    individual = helpers.select_random_distinct_numbers(int(gene_cnt), 0, len(graph.nodes))
    population.append(individual)

# test
population.append(gr.select_max_degree_nodes(graph, int(gene_cnt)))


for generation in range(generation_cnt):
    pop_fitness = ga.calc_pop_fitness(population)
    print("Generation : ", generation)
    print("Best result : ", pop_fitness)

    parents = ga.select_mating_pool(population)
    offsrings = ga.crossover(parents)
    for i in range(len(offsrings)) :
        offsrings[i] = ga.mutation(offsrings[i])
    # replace worst individuals with offsrings
    pop_fitness = {} 
    for i in range(len(population)) :
        pop_fitness[i] = ga.calc_fitness(population[i])
    sorted_pop_fitness = sorted(pop_fitness.items(), key=lambda x: x[1], reverse=True) 
    for i in range(len(offsrings)) :
        population[sorted_pop_fitness[i][0]] = offsrings[i]


# min_idx = -1
# fitness_min = float('inf')
# for i in range(pop_size) :
#     fitness = ga.calc_fitness(population[i])
#     if fitness < fitness_min :
#         fitness_min = fitness
#         min_idx = i

# for element in population[i]:
#     print(element, end="\n")

# print(ga.calc_fitness(population[i]))
    