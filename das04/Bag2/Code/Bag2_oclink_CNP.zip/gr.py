import networkx as nx
import matplotlib.pyplot as plt

graph_file = './OClinks.txt'

graph = nx.Graph()

with open(graph_file, 'r') as file:
    for line in file:
        if line.strip():  # Ignore empty lines
            parts = line.split(':')
            node = int(parts[0])
            if len(parts) == 1:
                graph.add_node(node)
                continue
            neighbors = list(map(int, parts[1].split()))
            graph.add_edges_from((node, neighbor) for neighbor in neighbors)

def draw(graph) :
    nx.draw(graph, with_labels=True, node_color='lightblue', node_size=500, font_size=10,
        edge_color='gray', width=1, style='dashed', alpha=0.8)
    plt.show()


def remove_nodes (graph, nodes = []) :
    new_graph = graph.copy()
    new_graph.remove_nodes_from(nodes)
    return new_graph


def calculate_fitness (graph) : 
    components = list(nx.connected_components(graph))
    res = 0 
    for component in components :
        res += len(component) * (len(component) - 1) / 2
    return res

def select_max_degree_nodes (graph, k) :
    res = []
    for i in range(k) :
        max_degree = 0
        max_degree_node = -1
        for node in graph.nodes :
            if len(graph[node]) > max_degree :
                max_degree = len(graph[node])
                max_degree_node = node
        res.append(max_degree_node)
        graph.remove_node(max_degree_node)
    return res